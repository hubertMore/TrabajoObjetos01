package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor

public abstract class Vehiculo {
    private String color;
    private String marca;
    private String modelo;
    
}

