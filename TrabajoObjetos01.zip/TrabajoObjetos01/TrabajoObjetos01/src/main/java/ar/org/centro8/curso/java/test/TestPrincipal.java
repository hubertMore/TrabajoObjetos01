package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Colectivo;
import ar.org.centro8.curso.java.entities.Radio;

public class TestPrincipal {
    public static void main(String[] args) {
        // Creando radios
        Radio radio1 = new Radio("Sony", 70);
        Radio radio2 = new Radio("Philips", 90);
        Radio radio3 = new Radio("Samsung", 130);

        // Creando vehículos
        AutoClasico autoClasico1 = new AutoClasico("Gris", "Toyota", "Corolla", radio2, 10000);
        AutoNuevo autoNuevo1 = new AutoNuevo("Azul", "Honda", "Civic", radio2, 20000);
        Colectivo colectivo1 = new Colectivo("Blanco", "Mercedes-Benz", "Sprinter", radio3, 50000);
        
        //Agregando radio a AutoClasico
        autoClasico1.agregarRadio(radio2);
        // Cambiando radio de AutoNuevo 
        autoNuevo1.cambiarRadio(radio1);
        //Agregando radio a Colectivo
        colectivo1.agregarRadio(radio3);
        //Cambiando radio a Colectivo
        //colectivo1.cambiarRadio(radio2);

        // Salida para verificar el funcionamiento
        
        System.out.println(autoClasico1);
        System.out.println(autoNuevo1);
        System.out.println(colectivo1);
        



    }
}
