package ar.org.centro8.curso.java.entities;

import lombok.Getter;

@Getter

public class AutoNuevo extends Vehiculo {
    private Radio radio;
    private double precio;

    public AutoNuevo(String color, String marca, String modelo, Radio radio, double precio) {
        super(color, marca, modelo);
        this.radio = radio;
        this.precio = precio;
        this.radio = new Radio(marca, 0);
    }

    @Override
    public String toString() {
        return super.toString()+" Auto Nuevo[" + radio + ", precio=" + precio + "]";
    }

    public void agregarRadio(Radio radio) {
        this.radio = radio;
    }

    public void cambiarRadio(Radio radio) {
        this.radio = radio;
    }
}


