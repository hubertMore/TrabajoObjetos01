package ar.org.centro8.curso.java.TrabajoObjetos01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoObjetos01Application {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoObjetos01Application.class, args);
	}

}
